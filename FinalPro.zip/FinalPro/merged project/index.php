<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restaurant Management System</title>
    <style>
        body {
            font-family: 'Georgia', serif;
            background-color: #f3f4f7;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            text-align: center;
            background: linear-gradient(to right,rgb(208, 225, 232),rgb(220, 244, 245));
            border: 1px solid #bbb;
            border-radius: 15px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            padding: 50px;
            width: 350px;
        }
        h1 {
            font-size: 28px;
            margin-bottom: 20px;
            color: #333;
        }
        .button {
            display: block;
            width: 100%;
            margin: 12px 0;
            padding: 12px;
            background-color:rgb(180, 233, 227);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-size: 18px;
            transition: background-color 0.3s, box-shadow 0.3s;
        }
        .button:hover {
            background-color:rgb(117, 188, 192);
            box-shadow: 0 0 8px rgba(0, 0, 0, 0.2);
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Restaurant Management System</h1>
        <a href="project/Tanvir Admin/view/login.php" class="button">Admin Login</a>
        <a href="project/polol seller/view/login.php" class="button">Seller Login</a>
        <a href="project/lamia customer/view/login.php" class="button">Customer Login</a>
    </div>
</body>
</html>