

<!DOCTYPE html>
<html>

 <?php include('header.php')?>

<style>

</style>

  <p><br></p><p><br></p>
        <table align="center" border="8px" style="padding: 15px;">
            <tr>
                <td>
                    <h2 align="center">Please Contact US </h2> 
                    <h2 align="center">21-44655-1@student.aiub.edu</h2>
                </td>
            </tr>
        </table>
<p><br></p><p><br></p>

<body>





</body>


  <?php include('footer.php')?>

  </html>