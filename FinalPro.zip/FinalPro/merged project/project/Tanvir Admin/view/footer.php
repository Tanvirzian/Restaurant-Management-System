<?php

	echo "<hr/><p></p><p align=center><br>Copyright <span>&#169;</span>2025 Restaurant Management System<br> 21-44655-1@student.aiub.edu </p>";

?>
