




<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/styles.css">
    <title></title>
</head>





<?php
	echo '
	<fieldset >

	    <p align="center" id="header1"><b>
	        <a href="homepage.php" >Home</a>&nbsp;&nbsp;&nbsp;
	        <a href="login.php" >Login</a>&nbsp;&nbsp;&nbsp;
	        <a href="registration.php" >Register</a>&nbsp;&nbsp;&nbsp;
			<a href="../../..">Portal</a>
	    </p> 
	    <center><img   src="../uploads/logo.jpg" id="img1"></center> 
	    
	</fieldset>
	';

?>