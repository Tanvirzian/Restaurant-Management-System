<?php
session_start();

if (isset($_SESSION['username'])) {


} else {

    header('location: login.php');
}

?>



<!DOCTYPE html>
<html>

<?php include('header2.php') ?>

<style>
    .error {
        color: #394393;
    }

    .buy-button {
        background-color:rgb(14, 189, 20);
        /* Green */
        color: white;
        padding: 10px 20px;
        font-size: 16px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        
        

    }

    .buy-button:hover {
        background-color: #45a049;
        /* Darker Green */
    }
</style>



<body onload="getCartList()">


    <p><br></p>
    <p><br></p>
    <div id="cartList"> </div>
    <p><br></p>
    <p><br></p>



    <center><h3></h3>
        <button class="buy-button" onclick="showAlert()">Buy</button></center>

</body>



<script type="text/javascript" src="../javascript/ajax.js">


</script>

<script>
        function showAlert() {
            alert("");
        }
    </script>



<br>
<p></p><br><br>
<p></p><br>
<div class="footer">
    <?php include('footer.php') ?>
</div>

</html>