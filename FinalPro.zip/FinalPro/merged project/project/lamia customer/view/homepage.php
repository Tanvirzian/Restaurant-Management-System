
<!DOCTYPE html>


<html lang="en">
<head>
    <title></title>
</head>


 <?php include('header.php')?>
<body>


    <fieldset>

        <p><br></p><p><br></p>
        <p>
            <h1 align="center" style= "color: #00AB71;">Welcome</h1> 
            <h2 align="center" style= "color: #00AB71;">To</h2>
            <h1 align="center" style= "color: #00AB71;">Restaurant Management System </h1>
        </p>

    
    <p><br></p><p><br></p>
    </fieldset>
</body>

<div class="footer">
      <?php include('footer.php')?> 
</div>

</html>

