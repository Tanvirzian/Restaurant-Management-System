function nameVal() {
    var name = document.getElementById("name").value;
    var regex = /^[a-zA-Z][a-zA-Z.\_\-\ ][\ a-zA-Z.\-\_]+/;

    if (regex.test(name)) {
        document.getElementById("nameErr").innerHTML = "";
    } else {
        document.getElementById("nameErr").innerHTML = "Only letters, periods (.), dashes (-), and spaces are allowed. Must contain at least two words.";
    }
}

function emailVal() {
    var email = document.getElementById("email").value;
    var regex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

    if (regex.test(email)) {
        document.getElementById("emailErr").innerHTML = "";
    } else {
        document.getElementById("emailErr").innerHTML = "Please enter a valid email address (e.g., anything@example.com).";
    }
}

function userVal() {
    var userName = document.getElementById("userName").value;
    var regex = /^[0-9a-zA-Z-_]{2,}[^\s.]$/;

    if (regex.test(userName)) {
        document.getElementById("usernameErr").innerHTML = "";
    } else {
        document.getElementById("usernameErr").innerHTML = "Username can only contain letters, numbers, dashes (-), and underscores (_), with at least two characters.";
    }
}

function passVal() {
    var password = document.getElementById("password").value;
    var regex = /^[0-9a-zA-Z@%#$]{8,}$/;

    if (regex.test(password)) {
        document.getElementById("passwordErr").innerHTML = "";
    } else {
        document.getElementById("passwordErr").innerHTML = "Password must be at least 8 characters long and contain only letters and allowed special characters (@, %, #, $).";
    }
}

function rePassVal() {
    var rePassword = document.getElementById("rePassword").value;
    var regex = /^[0-9a-zA-Z@%#$]{8,}$/;

    if (regex.test(rePassword)) {
        document.getElementById("rePasswordErr").innerHTML = "";
        if (document.getElementById("password").value !== document.getElementById("rePassword").value) {
            document.getElementById("rePasswordErr").innerHTML = "Passwords do not match.";
        }
    } else {
        document.getElementById("rePasswordErr").innerHTML = "Confirm password must match the original and meet the character requirements.";
    }
}