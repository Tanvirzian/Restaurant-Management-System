function userVal() {
    var userName = document.getElementById("userName").value;
    var regex = /^[0-9a-zA-Z-_]{2,}[^\s.]$/;

    if (regex.test(userName)) {
        document.getElementById("usernameErr").innerHTML = "";
    } else {
        document.getElementById("usernameErr").innerHTML = "Username should only contain letters (a-z, A-Z), dashes (-), and underscores (_), and must be at least 2 characters long without spaces or periods at the end.";
    }
}

function passVal() {
    var password = document.getElementById("password").value;
    var regex = /^[0-9a-zA-Z@%#$]{8,}$/;

    if (regex.test(password)) {
        document.getElementById("passwordErr").innerHTML = "";
    } else {
        document.getElementById("passwordErr").innerHTML = "Password must be at least 8 characters long and can include letters, numbers, and special characters like @, %, #, $, but no spaces.";
    }
}