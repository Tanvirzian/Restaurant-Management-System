
<!DOCTYPE html>


<html lang="en">
<head>
    <title></title>
</head>



 <?php include('header.php')?>
 <body>

    <table class="welcome-table">
        <tr>
            <td>
                <h2>WELCOME</h2>
                <h2>TO</h2>
                <h2>Restaurant Management System</h2>
            </td>
        </tr>
    </table>

</body>

<?php include('footer.php')?>

</html>

