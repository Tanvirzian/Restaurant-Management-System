
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/styles.css">
    <title></title>
</head>
<b>


<div class="header">

	    <p align="center" id="nav" style="font-size:22px" >
	        <a href="homepage2.php"  >Home</a>&nbsp;&nbsp;&nbsp;
			<a href="addProduct.php" >Add Food</a>&nbsp;&nbsp;&nbsp;
			<a href="checkProduct.php" >Check Food</a>&nbsp;&nbsp;&nbsp;
	        <a href="editProfile.php" >Edit Profile</a>&nbsp;&nbsp;&nbsp;
	        <a href="profile.php" >Profile</a>&nbsp;&nbsp;&nbsp;
	        <a href="logout.php" >Log Out</a>
	    </p> 
	</div>