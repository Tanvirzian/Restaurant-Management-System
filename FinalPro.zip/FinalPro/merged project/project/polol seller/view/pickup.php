

<?php
session_start();

if(isset($_SESSION['username'])){


}
else{

    header('location: login.php');
}

?>




<!DOCTYPE html>
<html>
<style>

</style>
<head>

</head>

 <?php include('header2.php')?>



 <br>
<div align="center">Search <input type="text" name="search" id="search"  onkeyup ="showResult(this.value)"></div>
<br>


<body onload="getAllPickup()">


<div id="pickup">

</div>






</body>

<script type="text/javascript" src="../javascript/ajax.js"></script>

<p><br></p>
  <?php include('footer.php')?>

  </html>