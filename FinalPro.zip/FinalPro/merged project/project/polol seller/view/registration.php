<!--  comments-->

<?php
session_start();
?>



<!DOCTYPE html>
<html>
<style>
  .error {
    color: #FF0000;
  }
</style>

<head>
  <title>Registration</title>
</head>
<?php include('header.php') ?>
<?php

// define variables and set to empty values
$nameErr = $emailErr = $genderErr = $birthdateErr = $degreeErr = $bloodgroupErr = $newpassErr = $renewpassErr = $usernameErr = "";

$name = $email = $gender = $birthdate = $newpass = $renewpass = $username = "";

$check = 0;

if ($_SERVER["REQUEST_METHOD"] == "POST") {



  //name validation//name validation//name validation
  if (empty($_POST["name"])) {
    $nameErr = "Name is required";
  } else {
    $name = test_input($_POST["name"]);
    //validating alphabet
    if (!preg_match("/^[a-zA-Z][a-zA-Z.\_\-]+ +[a-zA-Z.\-\_]+/", $name)) {
      $nameErr = "Contain a-z, A-Z  and at least two words";
    } else
      $check++;
    //!preg_match("/^[a-zA-Z-'{2,8} ]*$/",$name  
  }




  //email validation//email validation//email validation

  if (empty($_POST["email"])) {
    $emailErr = "Email is required";
  } else {
    $email = test_input($_POST["email"]);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailErr = "Must be a valid email_address : anything@example.Com";
    } else
      $check++;
  }

  //username username   
  if (empty($_POST["username"])) {
    $usernameErr = "username is required";
  } else {
    $username = test_input($_POST["username"]);
    //validating alphabet
    if (!preg_match("/^[0-9a-zA-Z-_]{2,}[^\s.]$/", $username)) {
      $usernameErr = "Must contain at least two characters and alpha numeric characters, (@),(-),(_)";
    } else
      $check++;
  }



  //password validation//password validation//password validation

  if (empty($_POST["newpass"])) {
    $newpassErr = " must need to fill password";
  } else
    $newpass = test_input($_POST["newpass"]);


  if (empty($_POST["renewpass"])) {
    $renewpassErr = " must need to fill confirm password";
  } else
    $renewpass = test_input($_POST["renewpass"]);


    if (!preg_match("/^[0-9a-zA-Z@%#$]{8,}$/",$newpass)) {
    $newpassErr = "Minimum (8) characters need  one special characters (@, #, $, %)";

  } else if ($_POST["newpass"] == $_POST["renewpass"]) {
    $check++;
  } else
    $renewpassErr = "didn't macth the password ";





  //gender validation//gender validation//gender validation

  if (empty($_POST["gender"])) {
    $genderErr = "Gender is required";
  } else {
    $gender = test_input($_POST["gender"]);
    $check++;
  }


  //date validation 
  if (empty($_POST["birthdate"])) {
    $birthdateErr = " select up year, month, date ";
  } else {
    $birthdate = test_input($_POST["birthdate"]);
    $check++;
  }


  //form changing 
  if ($check == 6) {
    $_SESSION['name'] = $_REQUEST['name'];
    $_SESSION['email'] = $_REQUEST['email'];
    $_SESSION['username'] = $_REQUEST['username'];
    $_SESSION['pass'] = $_REQUEST['newpass'];
    $_SESSION['dob'] = $_REQUEST['birthdate'];
    $_SESSION['gender'] = $_REQUEST['gender'];
    header('location:../controller/registrationDone.php');
  }
}


function test_input($data)
{
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>


<body>

  <p>
    <center>
      <h1 align="center" style="color: ;">Sign Up</h1>
      <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <span class="error">(*) All need to fill </span><br><br><br>


        <div style="border: 2px solid; width: 20%; padding: 10px;">
          <div>
            <label for="name"><b>NAME:</b></label>
            <input type="text" name="name" id="name" onkeyup="nameVal()"><br>
            <span class="error" id="nameErr">* <?php echo $nameErr; ?></span>
          </div>
          <br>
          <div>
            <label for="email"><b>EMAIL:</b></label>
            <input type="text" name="email" id="email" onkeyup="emailVal()"><br>
            <span class="error" id="emailErr">* <?php echo $emailErr; ?></span>
          </div>
          <br>
          <div>
            <label for="userName"><b>User Name:</b></label>
            <input type="text" name="username" id="userName" onkeyup="userVal()"><br>
            <span class="error" id="usernameErr">* <?php echo $usernameErr; ?></span>
          </div>
          <br>
          <div>
            <label for="password"><b>Password:</b></label>
            <input type="password" name="newpass" id="password" onkeyup="passVal()"><br>
            <span class="error" id="passwordErr">* <?php echo $newpassErr; ?></span>
          </div>
          <br>
          <div>
            <label for="rePassword"><b>Confirm Password:</b></label>
            <input type="password"s name="renewpass" id="rePassword" onkeyup="rePassVal()"><br>
            <span class="error" id="rePasswordErr">* <?php echo $renewpassErr; ?></span>
          </div>
          <br>
          <div>
            <label for="birthdate"><b>DATE OF BIRTH:</b></label>
            <input type="date" min="1940-01-01" max="2003-12-31" id="birthdate" name="birthdate"><br>
            <span class="error">* <?php echo $birthdateErr; ?></span>
          </div>
          <br>
          <div>
            <b>GENDER:</b><br>
            <input type="radio" name="gender" value="female">Female
            <input type="radio" name="gender" value="male">Male
            <input type="radio" name="gender" value="other">Other<br>
            <span class="error">* <?php echo $genderErr; ?></span>
          </div>
        </div>
        <br>
        <input type="submit" value="Register">&nbsp;&nbsp;
        <br><br><br><br>


    </center>
  </p>





  </form>



</body>

<script type="text/javascript" src="../javascript/registrationJavaScript.js"></script>

<p><br></p>
<?php include('footer.php') ?>

</html>