
<?php
session_start();
?>


<!DOCTYPE html>
<html>

 <?php include('header2.php')?>




<span style="color: green"> <b> <h1 align="center"><?php echo  "Update successfully completed ";?></h1> </span>

<body>





</body>
<?php include('footer.php')?>
</html>