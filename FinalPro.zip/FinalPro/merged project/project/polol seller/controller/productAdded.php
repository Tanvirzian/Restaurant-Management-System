

<?php
session_start();

if(isset($_SESSION['username'])){


}
else{

    header('location: login.php');
}

?>





<!DOCTYPE html>
<html>


<?php


include('../header2.php');


require_once '../model/model.php';

     $data['productId']                     =     $_SESSION['productId'];
     $data['productName']                     =     $_SESSION['productName'];
     $data['buyPrice']                    =     $_SESSION['buyPrice']; 
     $data['sellPrice']                   =     $_SESSION['sellPrice'];
     $data['image'] = $_SESSION['image'];


    if (addProduct($data)) {
        echo 'Successfully added!!';
        header('location:../view/addProductDone.php');
    } else {
        echo 'You are not allowed to access this page.';    
    }
     //echo "done";
     //addProduct($data);


?>

