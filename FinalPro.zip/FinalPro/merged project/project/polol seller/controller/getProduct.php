



<?php

    $q=$_GET["q"];
    


    $con = mysqli_connect('localhost','root','','restaurant');
    if (!$con) {
    die('Could not connect: ' . mysqli_error($con));
    }

    $sql="SELECT * FROM product WHERE Name LIKE '%{$q}%'";
    $result = mysqli_query($con,$sql);

    
    echo '<table class="product-table">
    <thead>
        <tr>
            <th>Food ID</th>
            <th>Food Name</th>
            <th>Buy Price</th>
            <th>Sell Price</th>
            <th>Image</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>';

    while($row = mysqli_fetch_array($result)) {
        echo "<tr>";
        echo "<td>" . $row['ID'] . "</td>";
        echo "<td>" . $row['Name'] . "</td>";
        echo "<td>" . $row['Buy_Price'] . "</td>";
        echo "<td>" . $row['Sell_Price'] . "</td>";
        echo '<td><img width="100px" src="../images/'.$row['image'].'" alt="Product Image"></td>';
        $id=$row['ID'];
        echo '<td>';
        echo '<button class="delete-btn" onclick="window.location.href=\'../controller/deleteProduct.php?q='.$id.'\';">Delete</button>';
        echo '</td>';
        echo "</tr>";
    }

    echo "</tbody></table>";
    

    mysqli_close($con);

  ?>